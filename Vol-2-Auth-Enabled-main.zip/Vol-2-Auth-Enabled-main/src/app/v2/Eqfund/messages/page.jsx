import MessagingApp from "./_components/MessagingApp";

const Index = () => {
  return <MessagingApp />;
};

export default Index;