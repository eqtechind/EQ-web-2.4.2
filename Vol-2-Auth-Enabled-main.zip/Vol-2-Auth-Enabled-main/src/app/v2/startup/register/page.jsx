import StartupRegistration from "@/components/StartupRegistration";

const Index = () => {
  return <StartupRegistration />;
};

export default Index;
